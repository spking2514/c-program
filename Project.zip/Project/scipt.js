﻿function Validate() {
    var password = document.TextBox5("txtPassword").value;
    var confirmPassword = document.TextBox6("txtConfirmPassword").value;
    if (password != confirmPassword) {
        alert("Passwords do not match.");
        return false;
    }
    return true;
}
window.history.forward();
function noBack() {
    window.history.forward();
}