﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

public partial class signin : System.Web.UI.Page
{
    SqlConnection cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\frotiafreshes.mdf;Integrated Security=True;User Instance=True");
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("signup.aspx");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string sql = "select * from login where username='" + TextBox7.Text + "'and password='" + TextBox5.Text + "'";
        SqlDataAdapter da = new SqlDataAdapter(sql, cn);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count == 1)
        {
            Session["user"] = TextBox7.Text;
            
            string Utype;
            Utype = dt.Rows[0][8].ToString().Trim();

            if (Utype == "U")
            {
                Response.Redirect("Userhome.aspx");
            }
            if (Utype == "A")
            {
                Response.Redirect("Adminhome.aspx");
            }
        }
        else
        {
            
        }
    }
}